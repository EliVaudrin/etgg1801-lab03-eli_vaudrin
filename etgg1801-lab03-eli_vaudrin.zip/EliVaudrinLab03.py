#ETGG 1801
#Eli Vaudrin
#Lab03 Modules
#9/19/20

import pygame
import time
import random

List = [493, 253, 211, 57, 78, 154, 389, 134, 207, 227]

pygame.display.init()
window = pygame.display.set_mode((1000, 800))

pygame.draw.polygon(window, (0, 182, 73), ((123, 0), (280, 98), (240, 280), (67, 278), (0, 73)))
pygame.draw.ellipse(window, (0, 43, 212), (231, 187, 156, 89))
pygame.draw.rect(window, (132, 43, 80), (67, 138, 121, 93))
pygame.draw.circle(window, (228, 0, 27), (475, 234), 56)
pygame.draw.rect(window, (0, 67, 188), (random.choice(List), random.choice(List), random.choice(List), random.choice(List)))
pygame.draw.polygon(window, (93, 0, 162), ((458, 142), (583, 231), (234, 354), (347, 198), (124,78)))
pygame.draw.circle(window, (0, 213, 42), (867, 689), 98)
pygame.draw.ellipse(window, (167, 0, 88), (568, 397, 369, 296))
pygame.draw.rect(window, (174,81, 0), (365, 576, 463,375))
pygame.draw.polygon(window, (0, 148, 107), ((335, 521), (325, 462), (354, 253), (489, 402), (621, 434)))

pygame.display.update()

time.sleep(10)

pygame.quit()

List2 = [479, 625, 342, 572, 271, 483, 784, 318, 393, 472]

pygame.display.init()
window2 = pygame.display.set_mode((1200, 1000))

pygame.draw.circle(window2, (195, 0, 60), (random.choice(List2), random.choice(List2)), random.choice(List2))
pygame.draw.ellipse(window2, (0, 139, 116), (random.choice(List2), random.choice(List2), random.choice(List2), random.choice(List2)))
pygame.draw.polygon(window2, (123, 68, 64), ((random.choice(List2), random.choice(List2)), (random.choice(List2), random.choice(List2)), (random.choice(List2), random.choice(List2)), (random.choice(List2), random.choice(List2)), (random.choice(List2), random.choice(List2))))
pygame.draw.rect(window2, (0, 134, 121), (random.choice(List2), random.choice(List2), random.choice(List2), random.choice(List2)))

pygame.display.update()

time.sleep(10)
pygame.quit()